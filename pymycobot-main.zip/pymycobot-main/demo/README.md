There are some demo files of **pymycobot**.

<!--`get_port.py`: output all port, choice one then write to `port.txt`, other test `.py` will read port string from `port.txt`.-->
